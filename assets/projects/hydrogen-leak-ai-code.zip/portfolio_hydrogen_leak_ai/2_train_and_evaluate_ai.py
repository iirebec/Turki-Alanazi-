"""
AI-Assisted Hydrogen Leak Detection: training and evaluation
=============================================================

What this program does
----------------------
A palladium-coated optical fibre sensor (a fibre Bragg grating) reflects one
colour (wavelength) of light. When hydrogen reaches the palladium, the coating
swells and stretches the fibre, so the reflected wavelength shifts. The problem
is that heat and mechanical pressure shift the same wavelength too, so one
reading cannot tell a real leak from a false alarm.

This program teaches an AI model to tell them apart by looking at HOW the
signal changes over two minutes, not just how big it is:
  - normal       : flat line with small noise
  - temperature  : slow, steady, almost straight rise
  - pressure     : quick rise, then falls back down
  - hydrogen_leak: rises, then levels off and stays up (the leak keeps going)

Steps
-----
1. Load 20,000 simulated sensor signals (5,000 of each type), each 31
   readings taken every 4 seconds over 120 seconds.
2. Describe each signal with 8 simple shape numbers (peak, average, final
   value, when the peak happens, early slope, late slope, how much it falls
   back, overall slope).
3. Train a Random Forest: 300 decision trees that each vote on the cause.
4. Test it on 25% of the signals it never saw during training.
5. Check whether its confidence is honest (when it says 95%, is it right 95%
   of the time?).
6. Provide a function that classifies any new 31-reading signal.

Run:   python 2_train_and_evaluate_ai.py
Needs: pinpoint_h2_single_sensor.csv in the same folder
       (create it with 1_generate_sensor_data.py)

Note: the training data is simulated from published sensor physics, not
measured on real hardware. Results show the method works on that simulation.
"""
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

TIME_STEPS = list(range(0, 121, 4))   # 31 readings, every 4 s for 120 s


def extract_shape_features(pm_readings):
    """Turn 31 wavelength-shift readings (in picometres) into 8 shape numbers."""
    series = np.array(pm_readings, dtype=float)
    t = np.array(TIME_STEPS, dtype=float)
    max_val = series.max()
    third = len(series) // 3
    return {
        "max_val": max_val,                                          # biggest shift
        "mean_val": series.mean(),                                   # average shift
        "final_val": series[-1],                                     # shift at the end
        "peak_frac": series.argmax() / (len(series) - 1),            # when the peak happens (0 = start, 1 = end)
        "early_slope": np.polyfit(t[:third], series[:third], 1)[0],  # how fast it rises at first
        "late_slope": np.polyfit(t[-third:], series[-third:], 1)[0], # still rising, flat, or falling at the end
        "decay_ratio": series[-1] / max_val if abs(max_val) > 1e-6 else 1.0,  # final / peak: did it fall back?
        "overall_slope": np.polyfit(t, series, 1)[0],                # overall trend
    }


def row_features(row):
    cols = [f"t{t:03d}_pm" for t in TIME_STEPS]
    return extract_shape_features(row[cols].to_numpy(dtype=float))


# ---------------- 1. TRAIN ----------------
df = pd.read_csv("pinpoint_h2_single_sensor.csv")
X = pd.DataFrame([row_features(r) for _, r in df.iterrows()])
y = df["true_cause"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)

model = RandomForestClassifier(n_estimators=300, random_state=42)
model.fit(X_train, y_train)
joblib.dump(model, "pinpoint_h2_model.joblib")

# ---------------- 2. ACCURACY CHECK (signals the model never saw) ----------------
pred = model.predict(X_test)
print(f"Accuracy on held-out test data: {accuracy_score(y_test, pred):.3f}\n")
print(classification_report(y_test, pred))
print("Confusion matrix (rows = true cause, columns = AI's answer):")
print(pd.DataFrame(confusion_matrix(y_test, pred, labels=model.classes_),
                   index=model.classes_, columns=model.classes_))

# ---------------- 3. CONFIDENCE CHECK ----------------
proba = model.predict_proba(X_test)
conf = proba.max(axis=1)
correct = pred == y_test.to_numpy()
print("\nConfidence vs. accuracy (is the AI honest about how sure it is?)")
for lo, hi in [(0, .6), (.6, .8), (.8, .95), (.95, 1.01)]:
    m = (conf >= lo) & (conf < hi)
    if m.sum():
        print(f"  confidence {lo:.0%}-{min(hi,1):.0%}: {m.sum():5d} signals, actually correct {correct[m].mean():.1%}")


# ---------------- 4. CLASSIFY ONE NEW SIGNAL ----------------
def predict_from_signal(pm_readings):
    """pm_readings: 31 wavelength shifts in pm (t = 0, 4, ..., 120 s).
    Returns (answer, confidence, caution, leak_risk).
    caution = True when the AI's top answer is not 'leak' but it still gives
    a leak a 20% or higher chance, so an operator should take a look."""
    if len(pm_readings) != 31:
        raise ValueError(f"Expected 31 readings, got {len(pm_readings)}")
    feats = pd.DataFrame([extract_shape_features(pm_readings)])
    p = model.predict_proba(feats)[0]
    classes = model.classes_
    top = p.argmax()
    answer, confidence = classes[top], p[top]
    leak_risk = p[list(classes).index("hydrogen_leak")]
    caution = leak_risk >= 0.20 and answer != "hydrogen_leak"
    return answer, confidence, caution, leak_risk


if __name__ == "__main__":
    # Example: replace with your own 31 readings
    demo = [0.0] * 31
    a, c, flag, risk = predict_from_signal(demo)
    print(f"\nDemo (flat signal): {a}, confidence {c:.0%}, leak risk {risk:.0%}, caution={flag}")
