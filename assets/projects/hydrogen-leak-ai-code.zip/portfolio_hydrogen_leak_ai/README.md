# AI-Assisted Hydrogen Leak Detection for Hydrogen Storage

An AI model that tells a real hydrogen leak apart from false alarms (temperature changes and pressure events) using a palladium-coated optical fibre sensor.

Built by Turki Alanazi (team leader), Abdulelah Altayar and Khalid Al-Subaie, supervised by Dr. Sattam Alharbi, University of Ha'il. Finalist (35 of 1,200 teams), Energy Hackathon, Ministry of Energy, Saudi Arabia, October 2026.

## The problem
- A fibre Bragg grating is a short section of optical fibre that reflects one wavelength of light.
- When it is coated with palladium, hydrogen makes the coating swell, which stretches the fibre and shifts the reflected wavelength. That shift is the leak signal.
- Heat and mechanical pressure shift the same wavelength. A single reading can't tell them apart, so a simple threshold gives false alarms.

## The idea
Each cause changes the signal differently over time:

![Signal shapes](figures/signal_shapes.png)

| Cause | Signal shape over 2 minutes |
|---|---|
| Normal | Flat, only noise |
| Temperature change | Slow, steady, almost straight rise |
| Pressure / strain event | Fast rise, then falls back |
| Hydrogen leak | Rises, then levels off and stays up |

The AI reads 31 readings (one every 4 s for 120 s), describes the signal with 8 shape numbers, and a **Random Forest** of 300 decision trees votes on the cause.

## Results (simulated data)
Trained on 15,000 signals and tested on 5,000 signals it had never seen (1,250 of each cause).

![Confusion matrix](figures/confusion_matrix.png)

- **Accuracy: 97.6%**
- Pressure events are recognised 100% of the time.
- The main remaining confusion is between weak hydrogen leaks and slow temperature rises, which look alike over a short 2-minute window.
- **The confidence is honest.** When the AI is 95–100% sure (4,093 of 5,000 signals), it is right 99.6% of the time. When it is under 60% sure, it is right only 57% of the time. So a low-confidence answer is a useful "go and check" signal.

![Feature importance](figures/feature_importance.png)

The model relies mostly on slopes and timing (the shape), not on the size of the signal.

## Files
| File | What it does |
|---|---|
| `1_generate_sensor_data.py` | Creates the 20,000 simulated sensor signals from published sensor physics |
| `2_train_and_evaluate_ai.py` | Trains the AI, tests it, checks its confidence, and classifies new signals |
| `3_make_figures.py` | Produces the figures above |
| `pinpoint_h2_single_sensor.csv` | The generated dataset |
| `results.txt` | Output of the training run |

## How to run
```bash
pip install numpy pandas scikit-learn joblib matplotlib
python 1_generate_sensor_data.py      # optional: the CSV is already included
python 2_train_and_evaluate_ai.py
python 3_make_figures.py
```

## Where the numbers come from
- **Published values:** temperature sensitivity of 12 pm/°C; strain sensitivity of 1.2 pm/µε; hydrogen response of 14–370 pm (Trouillet et al.; Buric et al.); hydrogen response curve traced from Schroeder et al. (2009).
- **Engineering assumptions:** pressure-event size (50–400 µε) and sensor noise (3 pm).

## Limitations
- All data is simulated. The model has not yet been tested on a real sensor.
- Events happen one at a time. Real tanks can see a leak during a temperature rise.
- This version uses one sensor. Locating a leak with several sensors along the tank is the next step.
