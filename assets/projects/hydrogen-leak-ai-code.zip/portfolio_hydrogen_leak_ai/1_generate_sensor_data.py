"""
PinPoint H2 - single-sensor training data (no array, no localization).

THE PROJECT, IN ONE PARAGRAPH
------------------------------
Problem: we can't tell if a hydrogen tank is leaking. Solution: a palladium-coated
optical fiber sensor. When hydrogen reaches the Pd coating, it absorbs it and
expands, straining the fiber and shifting the wavelength it reflects, that shift
is how we detect a leak. Second problem: that same wavelength shift also happens
from ordinary temperature change and from mechanical pressure/strain, so a raw
reading alone cannot tell a real leak apart from a false alarm. That is exactly
what the AI is for: given one sensor's signal over time, decide whether the cause
is temperature, pressure, or a real hydrogen leak.

WHAT'S REAL VS ASSUMED (unchanged from before, just no longer split across stations)
--------------------------------------------------------------------------------------
REAL, published:
  - Temperature coefficient: 12 pm/degC (converges across 5+ independent bare-fiber studies, 10-13 pm/degC)
  - Strain coefficient: 1.2 pm/microstrain (foundational bare-fiber value)
  - Hydrogen response magnitude: 14-370 pm (real values from Trouillet et al. and Buric et al.,
    strain-based Pd-coated FBGs)
  - Hydrogen response SHAPE: traced pixel-by-pixel from Figure 7 of Schroeder et al. (2009),
    the real, non-linear phase-transition curve (sharp rise between 1-2% H2, then flattening)
  - Response time: faster at higher concentration, matching Schroeder's and Buric's reported ranges

ENGINEERING ASSUMPTIONS, not from a paper:
  - Pressure-event magnitude (50-400 microstrain): no published hydrogen-tank hoop-strain figure found
  - Sensor read noise (3 pm): a reasonable margin, not this exact design's measured floor
"""

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

TEMP_COEFF_PM_PER_C = 12.0
STRAIN_COEFF_PM_PER_USTRAIN = 1.2
H2_MAX_RESPONSE_LOW_PM = 14.0
H2_MAX_RESPONSE_HIGH_PM = 370.0

_REAL_CONC_PCT = np.array([0, 1, 2, 3, 4, 5])
_REAL_SHIFT_PM = np.array([0, 8, 40, 44, 46, 47])
_REAL_SHIFT_FRACTION = _REAL_SHIFT_PM / _REAL_SHIFT_PM[-1]

def phase_transition_shape(conc_pct):
    """Real curve shape traced from Schroeder et al. Fig. 7."""
    return float(np.interp(conc_pct, _REAL_CONC_PCT, _REAL_SHIFT_FRACTION, right=1.0))

def response_time_s(conc_pct):
    base = np.interp(conc_pct, [0, 1, 4], [110, 110, 30])
    return max(10, base + RNG.normal(0, 8))

NOISE_STD_PM = 3.0
T_OBS_S = 120.0
DT_S = 4.0
TIME_STEPS = np.arange(0, T_OBS_S + DT_S, DT_S)  # 31 points

N_PER_CLASS = 5000
CLASSES = ["normal", "temperature", "pressure", "hydrogen_leak"]


def make_episode(episode_id, cause):
    row = {"episode_id": episode_id, "true_cause": cause}

    background_dT = RNG.uniform(-2, 2)
    dT_event = RNG.uniform(2, 22) if cause == "temperature" else 0.0
    strain_event = RNG.uniform(50, 400) if cause == "pressure" else 0.0
    pulse_peak_t = RNG.uniform(15, 45)
    pulse_width = RNG.uniform(8, 20)
    strain_baseline = RNG.normal(0, 12)

    row["true_dT_event_c"] = dT_event
    row["true_strain_event_ustrain"] = strain_event
    row["true_h2_conc_pct"] = np.nan

    h2_final_pm, tau = 0.0, None
    if cause == "hydrogen_leak":
        peak_conc = RNG.uniform(0.3, 4.0)          # % v/v at the sensor
        h2_sensitivity = RNG.uniform(H2_MAX_RESPONSE_LOW_PM, H2_MAX_RESPONSE_HIGH_PM)
        h2_final_pm = h2_sensitivity * phase_transition_shape(peak_conc)
        tau = response_time_s(peak_conc)
        row["true_h2_conc_pct"] = peak_conc

    series = []
    for t in TIME_STEPS:
        temp_t = TEMP_COEFF_PM_PER_C * (background_dT + dT_event * (t / T_OBS_S))
        strain_t = STRAIN_COEFF_PM_PER_USTRAIN * (
            strain_baseline + strain_event * np.exp(-((t - pulse_peak_t) ** 2) / (2 * pulse_width ** 2))
        )
        h2_t = h2_final_pm * (1 - np.exp(-t / tau)) if cause == "hydrogen_leak" else 0.0
        noise_t = RNG.normal(0, NOISE_STD_PM)
        series.append(temp_t + strain_t + h2_t + noise_t)

    for k, t in enumerate(TIME_STEPS):
        row[f"t{int(t):03d}_pm"] = round(series[k], 2)

    return row


rows = []
episode_id = 0
for cause in CLASSES:
    for _ in range(N_PER_CLASS):
        rows.append(make_episode(episode_id, cause))
        episode_id += 1

df = pd.DataFrame(rows).sample(frac=1, random_state=42).reset_index(drop=True)
df.to_csv("pinpoint_h2_single_sensor.csv", index=False)
print(f"Generated {len(df)} episodes -> pinpoint_h2_single_sensor.csv")
print(df["true_cause"].value_counts())
