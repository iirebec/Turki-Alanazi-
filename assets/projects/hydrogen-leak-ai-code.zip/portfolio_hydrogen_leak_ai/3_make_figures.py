"""
Makes the portfolio figures from the dataset and the trained model.
Run after 2_train_and_evaluate_ai.py (needs pinpoint_h2_model.joblib).
  figures/signal_shapes.png      one example signal of each cause
  figures/confusion_matrix.png   what the AI answered vs the true cause
  figures/feature_importance.png which shape numbers the AI relies on most
"""
import importlib.util, sys
import numpy as np
import pandas as pd
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

TIME_STEPS = list(range(0, 121, 4))
COLS = [f"t{t:03d}_pm" for t in TIME_STEPS]
ORDER = ["normal", "temperature", "pressure", "hydrogen_leak"]
LABEL = {"normal": "Normal", "temperature": "Temperature change",
         "pressure": "Pressure / strain event", "hydrogen_leak": "Hydrogen leak"}
COLOR = {"normal": "#7A8B99", "temperature": "#E8A33D",
         "pressure": "#3D7FE8", "hydrogen_leak": "#2BA84A"}


def extract_shape_features(pm_readings):
    series = np.array(pm_readings, dtype=float)
    t = np.array(TIME_STEPS, dtype=float)
    max_val = series.max()
    third = len(series) // 3
    return {
        "max_val": max_val, "mean_val": series.mean(), "final_val": series[-1],
        "peak_frac": series.argmax() / (len(series) - 1),
        "early_slope": np.polyfit(t[:third], series[:third], 1)[0],
        "late_slope": np.polyfit(t[-third:], series[-third:], 1)[0],
        "decay_ratio": series[-1] / max_val if abs(max_val) > 1e-6 else 1.0,
        "overall_slope": np.polyfit(t, series, 1)[0],
    }


df = pd.read_csv("pinpoint_h2_single_sensor.csv")
model = joblib.load("pinpoint_h2_model.joblib")
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})

# 1. Example signal shapes (median-sized example of each class, for a fair picture)
fig, axs = plt.subplots(2, 2, figsize=(10, 6.5), sharex=True)
for ax, cause in zip(axs.flat, ORDER):
    sub = df[df.true_cause == cause]
    rng = (sub[COLS].max(axis=1) - sub[COLS].min(axis=1))
    row = sub.loc[(rng - rng.median()).abs().idxmin(), COLS].to_numpy(float)
    ax.plot(TIME_STEPS, row, "-o", color=COLOR[cause], ms=3.5, lw=2)
    ax.set_title(LABEL[cause], fontweight="bold")
    ax.set_ylabel("Wavelength shift (pm)")
    ax.grid(alpha=0.25)
for ax in axs[1]:
    ax.set_xlabel("Time (s)")
fig.suptitle("Each cause leaves a different signal shape over 2 minutes", fontsize=13, fontweight="bold")
fig.tight_layout()
fig.savefig("figures/signal_shapes.png", dpi=200)
plt.close(fig)

# 2. Confusion matrix on the same held-out 25% used in training
X = pd.DataFrame([extract_shape_features(r) for r in df[COLS].to_numpy(float)])
y = df["true_cause"]
_, X_test, _, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
pred = model.predict(X_test)
cm = confusion_matrix(y_test, pred, labels=ORDER)
fig, ax = plt.subplots(figsize=(6.8, 5.6))
ax.imshow(cm, cmap="Greens")
for i in range(4):
    for j in range(4):
        ax.text(j, i, cm[i, j], ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=12)
ticks = [LABEL[c].replace(" / ", "/\n").replace(" change", "\nchange").replace(" leak", "\nleak") for c in ORDER]
ax.set_xticks(range(4)); ax.set_xticklabels(ticks, fontsize=9.5)
ax.set_yticks(range(4)); ax.set_yticklabels(ticks, fontsize=9.5)
ax.set_xlabel("AI's answer"); ax.set_ylabel("True cause")
acc = (pred == y_test.to_numpy()).mean()
ax.set_title(f"Test on 5,000 unseen simulated signals: {acc:.1%} correct", fontweight="bold")
for s in ax.spines.values():
    s.set_visible(False)
fig.tight_layout()
fig.savefig("figures/confusion_matrix.png", dpi=200)
plt.close(fig)

# 3. Feature importance
names = {"overall_slope": "Overall slope", "late_slope": "Slope at the end",
         "decay_ratio": "Falls back? (final / peak)", "early_slope": "Slope at the start",
         "peak_frac": "When the peak happens", "final_val": "Final value",
         "mean_val": "Average value", "max_val": "Peak value"}
imp = pd.Series(model.feature_importances_, index=X.columns).sort_values()
fig, ax = plt.subplots(figsize=(7.5, 4.5))
ax.barh([names[k] for k in imp.index], imp.values * 100, color="#2BA84A")
for i, v in enumerate(imp.values * 100):
    ax.text(v + 0.4, i, f"{v:.1f}%", va="center", fontsize=10)
ax.set_xlabel("Share of the AI's decision (%)")
ax.set_title("What the AI looks at: the signal's shape, not just its size", fontweight="bold")
fig.tight_layout()
fig.savefig("figures/feature_importance.png", dpi=200)
plt.close(fig)
print("Saved figures to figures/")
print(imp.sort_values(ascending=False).round(3))
